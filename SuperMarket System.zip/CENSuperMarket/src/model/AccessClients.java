package model;

public class AccessClients {

}
