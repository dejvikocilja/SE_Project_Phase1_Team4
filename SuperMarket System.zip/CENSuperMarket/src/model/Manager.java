package model;

public class Manager {

}
